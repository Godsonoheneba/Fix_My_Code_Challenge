# React-Bootstrap Documentation Website

This website is single page app built on
[React](http://facebook.github.io/react/), with styles and structure taken from
the [Bootstrap](http://getbootstrap.com/) docs website.  The app is statically
generated to HTML via node and then hosted it by pushing HTML to [GitHub
Pages](http://pages.github.com/).

Source can be found in the
[react-bootstrap](https://github.com/react-bootstrap/react-bootstrap) repo.
