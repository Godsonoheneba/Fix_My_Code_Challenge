const panelInstance = (
  <Panel footer="Panel footer">
    Panel content
  </Panel>
);

React.render(panelInstance, mountNode);
